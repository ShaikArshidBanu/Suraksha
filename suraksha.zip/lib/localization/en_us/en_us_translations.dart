final Map<String, String> enUs = {
  // getting started page (flutter pg) Screen
  "lbl_login": "Login", "lbl_suraksha": "Suraksha",
  "msg_women_safety_app": "women safety app",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
