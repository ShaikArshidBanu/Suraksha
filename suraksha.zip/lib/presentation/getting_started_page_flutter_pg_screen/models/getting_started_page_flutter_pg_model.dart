/// This class defines the variables used in the [getting_started_page_flutter_pg_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class GettingStartedPageFlutterPgModel {}
